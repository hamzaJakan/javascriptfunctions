function lastElement(arr) {
  return arr[arr.length - 1];
}
