function additionner(a, b) {
  return a + b;
}