function diviser(a, b) {


  if (b === 0) {


    console.log("Division par zéro impossible !");
    return NaN;
  }
  return a / b;
}
