function multiplier(a, b) {
  return a * b;
}
