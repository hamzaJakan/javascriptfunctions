function soustraire(a, b) {
  return a - b;
}
