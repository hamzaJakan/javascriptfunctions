function PairImpair(nombre) {

  if (nombre % 2 === 0) {

    return "pair";
  }
  else {
    return "impair";
  }
}
